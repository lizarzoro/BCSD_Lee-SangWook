#include "Ref.h"

CRef::CRef() : m_iRef(0) {
}


CRef::~CRef() {
}
