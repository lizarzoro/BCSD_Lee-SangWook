#pragma once
// Scene Type
enum SCENE_CREATE {
	SC_CURRENT,
	SC_NEXT
};